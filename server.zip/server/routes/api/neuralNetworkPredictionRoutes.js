const express = require('express');
const router = express.Router();
const predictionController = require('../../controllers/neuralNetworkPredictionController');

router.route('/').get(predictionController);

module.exports = router;
